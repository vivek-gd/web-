let hours=0;
let minutes=0;
let seconds=0;
let interval;

const hoursElement=document.getElementById('hours');
const minutesElement=document.getElementById('minutes');
const secondsElement=document.getElementById('seconds');
const startButton=document.getElementById('startButton');
const pauseButton=document.getElementById('pauseButton');
const resetButton=document.getElementById('resetButton');

function updateTimer(){
    seconds++;
    if (seconds===60){
        seconds=0;
        minutes++;
        if(minutes===60){
            minutes=0;
            hours++;

        }
    }

    hoursElement.textContent=hours.toString().padStart(2,'0');
    minutesElement.textContent=minutes.toString().padStart(2,'0');
    secondsElement.textContent=seconds.toString().padStart(2,'0');
}

function startTimer(){
    if(!interval){
        interval=setInterval(updateTimer,1000);
    }
}

function pauseTimer(){
    clearInterval(interval);
    interval=null;
}

function resetTimer(){
    clearInterval(interval);
    interval=null;
    hours=0;
    minutes=0;
    seconds=0;
    hoursElement.textContent='00';
    minutesElement.textContent='00';
    secondsElement.textContent='00';
}
// 添加事件监听器
startButton.addEventListener('click',startTimer);
pauseButton.addEventListener('click',pauseTimer);
resetButton.addEventListener('click',resetTimer);